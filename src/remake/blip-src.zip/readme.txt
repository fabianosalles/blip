WINGAMES COLLECTION 98 SOURCE CODE
--------------------------------------

Webiste:
http://www.gferrari.com

(C) 1998 by Giulio Ferrari
giulio.ferrari@edis.it

----------

This source code is distributed for free; you can use, modify, and redistribute it freely,
provided that you give proper credit to the author in the program. Use the source at your
own risk; I'm not responsible for any damage on your computer.

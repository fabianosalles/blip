WINGAMES COLLECTION 98 SOURCE CODE
--------------------------------------

Internet address:
http://www.geocities.com/SiliconValley/Lab/2106/

(C) 1998 by Giulio Ferrari

----------

License:
This software is distributed for FREE; you can use and distribute it freely,
provided that you do not modify in any way the files included in the package.

I'm not responsible for any damage on your computer, but please let me know if
there are bugs or particular problems running one of the games.

----------

Contact the author:

Giulio Ferrari
giuliof@iol.it



